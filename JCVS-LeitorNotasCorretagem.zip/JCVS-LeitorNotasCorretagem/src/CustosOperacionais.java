import java.util.Date;

public class CustosOperacionais {

	private Double taxaOperacional;
	private Double execucao;
	private Double taxaCustodia;
	private Double imposto;
	private Double irrf;
	private Double outros;
	private Double totalCustoDespesas;
	private Double totalLiquidado;
	private Date dataLiquidacao;

	public Double getTaxaOperacional() {
		return taxaOperacional;
	}

	public void setTaxaOperacional(Double taxaOperacional) {
		this.taxaOperacional = taxaOperacional;
	}

	public Double getExecucao() {
		return execucao;
	}

	public void setExecucao(Double execucao) {
		this.execucao = execucao;
	}

	public Double getTaxaCustodia() {
		return taxaCustodia;
	}

	public void setTaxaCustodia(Double taxaCustodia) {
		this.taxaCustodia = taxaCustodia;
	}

	public Double getImposto() {
		return imposto;
	}

	public void setImposto(Double imposto) {
		this.imposto = imposto;
	}

	public Double getIrrf() {
		return irrf;
	}

	public void setIrrf(Double irrf) {
		this.irrf = irrf;
	}

	public Double getOutros() {
		return outros;
	}

	public void setOutros(Double outros) {
		this.outros = outros;
	}

	public Double getTotalCustoDespesas() {
		return totalCustoDespesas;
	}

	public void setTotalCustoDespesas(Double totalCustoDespesas) {
		this.totalCustoDespesas = totalCustoDespesas;
	}

	public Double getTotalLiquidado() {
		return totalLiquidado;
	}

	public void setTotalLiquidado(Double totalLiquidado) {
		this.totalLiquidado = totalLiquidado;
	}

	public Date getDataLiquidacao() {
		return dataLiquidacao;
	}

	public void setDataLiquidacao(Date dataLiquidacao) {
		this.dataLiquidacao = dataLiquidacao;
	}

}
