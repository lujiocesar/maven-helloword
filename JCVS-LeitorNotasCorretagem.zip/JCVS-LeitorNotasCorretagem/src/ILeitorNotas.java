
public interface ILeitorNotas {

	public String extrairOperacoesFinanceiras();

	public String extrairIdentificacao();

	public String extrairResumoNegocio();

	public String extrairResumoFinanceiro();
	
	public String extrairCustosOperacionais();

}
