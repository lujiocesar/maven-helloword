import java.util.LinkedHashMap;

public abstract class LeitorNotasCorretagem implements ILeitorNotas {
	
	private String[] vetorLinhas;

	private LinkedHashMap<Integer, String> linhasPorID;
	private LinkedHashMap<String, Integer> linhasPorConteudo;

	public String[] getVetorLinhas() {
		return vetorLinhas;
	}

	public void setVetorLinhas(String vetorLinhas) {
		this.vetorLinhas = vetorLinhas.split("\r\n");

		this.setLinhasPorConteudo(new LinkedHashMap<String, Integer>());
		this.setLinhasPorID(new LinkedHashMap<Integer, String>());

		for (int i = 0; i < this.vetorLinhas.length; i++) {

			this.getLinhasPorID().put(i, this.vetorLinhas[i]);
			this.getLinhasPorConteudo().put(this.vetorLinhas[i], i);
		}
	}

	public void setVetorLinhas(String[] vetorLinhas) {
		this.vetorLinhas = vetorLinhas;
	}

	public LinkedHashMap<Integer, String> getLinhasPorID() {
		return linhasPorID;
	}

	private void setLinhasPorID(LinkedHashMap<Integer, String> linhasPorID) {
		this.linhasPorID = linhasPorID;
	}

	public LinkedHashMap<String, Integer> getLinhasPorConteudo() {
		return linhasPorConteudo;
	}

	private void setLinhasPorConteudo(LinkedHashMap<String, Integer> linhasPorConteudo) {
		this.linhasPorConteudo = linhasPorConteudo;
	}

}
