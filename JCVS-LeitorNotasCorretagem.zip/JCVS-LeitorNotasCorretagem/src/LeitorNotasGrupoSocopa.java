
public class LeitorNotasGrupoSocopa extends LeitorNotasCorretagem {

	@Override
	public String extrairOperacoesFinanceiras() {
		StringBuilder sbRetorno = new StringBuilder();
		
		int idxInicio = this.getLinhasPorConteudo().get("T - Liquida��o pelo Bruto I - POP") + 1;
		int idxFim = this.getVetorLinhas().length;
		
		for ( ; idxInicio < idxFim; idxInicio++) {
			
			sbRetorno.append(this.getLinhasPorID().get(idxInicio)).append("!");
		}
		sbRetorno.append("@");
		return sbRetorno.toString();
	}

	@Override
	public String extrairIdentificacao() {
		StringBuilder sbRetorno = new StringBuilder();
		
		int idxInicio = this.getLinhasPorConteudo().get("Nr. Nota");
		int idxFim = idxInicio + 6; //( 6 linhas)
		
		for ( ; idxInicio < idxFim; idxInicio = idxInicio+2) {
			
			sbRetorno.append(this.getLinhasPorID().get(idxInicio)).append("=").append(this.getLinhasPorID().get(idxInicio+1)).append(";");
		}
		sbRetorno.append("@");
		return sbRetorno.toString();
	}

	@Override
	public String extrairResumoNegocio() {
		StringBuilder sbRetorno = new StringBuilder();
		
		int idxInicio = this.getLinhasPorConteudo().get("Resumo dos Neg�cios Resumo Financeiro D/C") + 1;
		int idxFim = this.getLinhasPorConteudo().get("Especifica��es Diversas Corretagem/Despesas");
		
		for ( ; idxInicio <= idxFim; idxInicio++) {
			
			sbRetorno.append(this.getLinhasPorID().get(idxInicio)).append("\r\n");
			
		}
		return sbRetorno.toString();
	}

	@Override
	public String extrairResumoFinanceiro() {
		StringBuilder sbRetorno = new StringBuilder();
		
		int idxInicio = this.getLinhasPorConteudo().get("Resumo dos Neg�cios Resumo Financeiro D/C") + 1;
		int idxFim = this.getLinhasPorConteudo().get("Especifica��es Diversas Corretagem/Despesas");
		
		for ( ; idxInicio <= idxFim; idxInicio++) {
			
			sbRetorno.append(this.getLinhasPorID().get(idxInicio)).append("\r\n");
			
		}
		return sbRetorno.toString();
	}

	@Override
	public String extrairCustosOperacionais() {
		StringBuilder sbRetorno = new StringBuilder();
		
		int idxInicio = this.getLinhasPorConteudo().get("Especifica��es Diversas Corretagem/Despesas") + 1;
		
		int idxFim = this.getLinhasPorConteudo().get("2 - Corretora ou pessoa vinculada atuou na");
		
		for ( ; idxInicio < idxFim; idxInicio++) {
			
			sbRetorno.append(this.getLinhasPorID().get(idxInicio)).append("\r\n");
		}
		return sbRetorno.toString();
	}

}
