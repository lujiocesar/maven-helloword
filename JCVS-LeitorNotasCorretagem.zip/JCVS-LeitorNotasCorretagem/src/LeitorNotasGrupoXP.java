
public class LeitorNotasGrupoXP extends LeitorNotasCorretagem {

	@Override
	public String extrairOperacoesFinanceiras() {
		StringBuilder sbRetorno = new StringBuilder();
		
		int idxInicio = this.getLinhasPorConteudo().get("Neg�cios realizados") + 2;
		int idxFim = this.getLinhasPorConteudo().get("NOTA DE NEGOCIA��O");
		
		if( idxInicio < idxFim ) { //leitura de notas 1 p�gina 
		
			for ( ; idxInicio < idxFim; idxInicio++) {
				
				sbRetorno.append(this.getLinhasPorID().get(idxInicio)).append("!");
			}
			sbRetorno.append("@");
			
		}else { //leitura de notas + de 1 p�gina 
			
			idxInicio = 0;
			idxFim = this.getLinhasPorConteudo().get("Neg�cios realizados");
			
			for ( ; idxInicio < idxFim; idxInicio++) {
				
				sbRetorno.append(this.getLinhasPorID().get(idxInicio)).append("!");
			}
			sbRetorno.append("@");
		}
		
		return sbRetorno.toString();
	}

	@Override
	public String extrairIdentificacao() {
		StringBuilder sbRetorno = new StringBuilder();
		
		int idxInicio = this.getLinhasPorConteudo().get("Nr. nota");
		int idxFim = idxInicio + 6; //( 6 linhas)
		
		for ( ; idxInicio < idxFim; idxInicio = idxInicio+2) {
			
			sbRetorno.append(this.getLinhasPorID().get(idxInicio)).append("=").append(this.getLinhasPorID().get(idxInicio+1)).append(";");
		}
		sbRetorno.append("@");
		return sbRetorno.toString();
	}

	@Override
	public String extrairResumoNegocio() {
		StringBuilder sbRetorno = new StringBuilder();
		
		int idxInicio = this.getLinhasPorConteudo().get("Complemento nome P. Vinc") + 2;
		int idxInicio2 = this.getLinhasPorConteudo().get("Deb�ntures");
		int idxFim = this.getLinhasPorConteudo().get("Valor das opera��es ");
		
		for ( ; idxInicio2 <= idxFim; ) {
			
			sbRetorno.append(this.getLinhasPorID().get(idxInicio2)).append("=").append(this.getLinhasPorID().get(idxInicio)).append(";");
			
			idxInicio++;
			idxInicio2++;
		}
		return sbRetorno.toString();
	}

	@Override
	public String extrairResumoFinanceiro() {
		StringBuilder sbRetorno = new StringBuilder();
		
		int idxInicio = this.getLinhasPorConteudo().get("B - Deb�ntures L - Precat�rio") + 1;
		int idxFim = idxInicio + 8; //( 8 linhas)
		
		for ( ; idxInicio < idxFim; idxInicio++) {
			
			sbRetorno.append(this.getLinhasPorID().get(idxInicio)).append("\r\n");
		}
		return sbRetorno.toString();
	}

	@Override
	public String extrairCustosOperacionais() {
		StringBuilder sbRetorno = new StringBuilder();
		
		int idxInicio = this.getLinhasPorConteudo().get("B - Deb�ntures L - Precat�rio") + 10;
		int idxFim = idxInicio + 9; //( 9 linhas)
		
		for ( ; idxInicio < idxFim; idxInicio++) {
			
			sbRetorno.append(this.getLinhasPorID().get(idxInicio)).append("\r\n");
		}
		return sbRetorno.toString();
	}

}
