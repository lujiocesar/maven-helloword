import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Arrays;
import java.util.LinkedList;

import org.apache.commons.io.comparator.LastModifiedFileComparator;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.text.PDFTextStripper;

public class Main {

	public static void main(String[] args) {

		//executarNotasGrupoRico();
//		executarNotasGrupoSocopa();
		executarNotasGrupoXP();
	}
	
	public static void executarNotasGrupoRico() {

		PDDocument document;
		try {

			File path = new File("D:\\TEMP\\notasGrupoRico\\");
			File[] arquivos = path.listFiles();
			Arrays.sort(arquivos, LastModifiedFileComparator.LASTMODIFIED_COMPARATOR);
			// Arrays.sort(arquivos,
			// LastModifiedFileComparator.LASTMODIFIED_REVERSE);

			StringBuilder sbExportCSV = new StringBuilder();

			LinkedList<NotaCorretagem> notas = new LinkedList<>();

			for (File file : arquivos) {

				if (file.isFile()) {

					document = PDDocument.load(file);

					if (!document.isEncrypted()) {

						notas = new LinkedList<>();

						PDFTextStripper stripper = new PDFTextStripper();

						for (int p = 1; p <= document.getNumberOfPages(); ++p) {

							stripper.setStartPage(p);
							stripper.setEndPage(p);

							String text = stripper.getText(document);

							LeitorNotasGrupoXP leitorSocopa = new LeitorNotasGrupoXP();
							leitorSocopa.setVetorLinhas(text);

							StringBuilder saida = new StringBuilder();
							saida.append("Arquivo").append("=").append(file.getName()).append(";");
							saida.append(leitorSocopa.extrairIdentificacao());
							saida.append(leitorSocopa.extrairOperacoesFinanceiras());
							// saida.append(leitorXP.extrairResumoNegocio());
							// saida.append(leitorXP.extrairResumoFinanceiro());
							// saida.append(leitorXP.extrairCustosOperacionais());
							// System.out.println(saida.toString());

							notas.add(new NotaCorretagem(saida.toString(), new Corretora("RICO INVESTIMENTOS")));
						}
					}

					document.close();

					StringBuilder sbExport = new StringBuilder();
					for (NotaCorretagem notaCorretagem : notas) {
						StringBuilder sbExportTemp = new StringBuilder();

						for (OperacaoFinanceira operacaoFinanceira : notaCorretagem.getOperacaoes()) {

							// sbExportTemp.append(notaCorretagem.exportCSV());
							// sbExportTemp.append(operacaoFinanceira.exportCSV()).append("\r\n");
							sbExportTemp.append(operacaoFinanceira.exportStatusInvest()).append("\r\n");

							// if (!operacaoFinanceira.exportAGF().equals("")) {
							// sbExportTemp.append(operacaoFinanceira.exportAGF()).append("\r\n");
							// }

							// System.out.print(new
							// StringBuilder(operacaoFinanceira.getNomeAtivo()).append("\r\n"));
						}
						sbExport.append(sbExportTemp);
						System.out.print(sbExportTemp.toString());
					}

					FileWriter fr = new FileWriter(new File(
							"D:\\TEMP\\notasGrupoRico\\output\\".concat(file.getName()).replaceAll("pdf", "csv")));
					fr.write(sbExport.toString());
					fr.flush();
					fr.close();

					sbExportCSV.append(sbExport);
				}

				FileWriter fr = new FileWriter(new File("D:\\TEMP\\notasGrupoRico\\output\\saida.csv"));
				fr.write(sbExportCSV.toString());
				fr.flush();
				fr.close();
			}

		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}	

	public static void executarNotasGrupoXP() {

		PDDocument document;
		try {

			File path = new File("D:\\TEMP\\notasGrupoXP\\");
			File[] arquivos = path.listFiles();
			Arrays.sort(arquivos, LastModifiedFileComparator.LASTMODIFIED_COMPARATOR);

			StringBuilder sbExportCSV = new StringBuilder();

			LinkedList<NotaCorretagem> notas = new LinkedList<>();

			for (File file : arquivos) {

				if (file.isFile()) {

					document = PDDocument.load(file);

					if (!document.isEncrypted()) {

						notas = new LinkedList<>();

						PDFTextStripper stripper = new PDFTextStripper();

						for (int p = 1; p <= document.getNumberOfPages(); ++p) {

							stripper.setStartPage(p);
							stripper.setEndPage(p);

							String text = stripper.getText(document);

							LeitorNotasGrupoXP leitorSocopa = new LeitorNotasGrupoXP();
							leitorSocopa.setVetorLinhas(text);

							StringBuilder saida = new StringBuilder();
							saida.append("Arquivo").append("=").append(file.getName()).append(";");
							saida.append(leitorSocopa.extrairIdentificacao());
							saida.append(leitorSocopa.extrairOperacoesFinanceiras());
							// saida.append(leitorXP.extrairResumoNegocio());
							// saida.append(leitorXP.extrairResumoFinanceiro());
							// saida.append(leitorXP.extrairCustosOperacionais());
							// System.out.println(saida.toString());

							notas.add(new NotaCorretagem(saida.toString(), new Corretora("CLEAR CORRETORA")));
						}
					}

					document.close();

					StringBuilder sbExport = new StringBuilder();
					for (NotaCorretagem notaCorretagem : notas) {
						StringBuilder sbExportTemp = new StringBuilder();

						for (OperacaoFinanceira operacaoFinanceira : notaCorretagem.getOperacaoes()) {

							sbExportTemp.append(operacaoFinanceira.exportStatusInvest()).append("\r\n");
							
//							 if (!operacaoFinanceira.exportAGF().equals("")) {
//								 sbExportTemp.append(operacaoFinanceira.exportAGF()).append("\r\n");
//							 }

							// System.out.print(new
							// StringBuilder(operacaoFinanceira.getNomeAtivo()).append("\r\n"));
						}
						sbExport.append(sbExportTemp);
						System.out.print(sbExportTemp.toString());
					}

					FileWriter fr = new FileWriter(new File(
							"D:\\TEMP\\notasGrupoXP\\output\\".concat(file.getName()).replaceAll("pdf", "csv")));
					fr.write(sbExport.toString());
					fr.flush();
					fr.close();

					sbExportCSV.append(sbExport);
				}

				FileWriter fr = new FileWriter(new File("D:\\TEMP\\notasGrupoXP\\output\\saida.csv"));
				fr.write(sbExportCSV.toString());
				fr.flush();
				fr.close();
			}

		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	public static void executarNotasGrupoSocopa() {

		PDDocument document;
		try {

			File path = new File("D:\\TEMP\\notasGrupoSocopa\\");
			File[] arquivos = path.listFiles();
			Arrays.sort(arquivos, LastModifiedFileComparator.LASTMODIFIED_COMPARATOR);

			StringBuilder sbExportCSV = new StringBuilder();

			LinkedList<NotaCorretagem> notas = new LinkedList<>();

			for (File file : arquivos) {

				if (file.isFile()) {

					document = PDDocument.load(file);

					if (!document.isEncrypted()) {

						notas = new LinkedList<>();

						PDFTextStripper stripper = new PDFTextStripper();

						for (int p = 1; p <= document.getNumberOfPages(); ++p) {

							stripper.setStartPage(p);
							stripper.setEndPage(p);

							String text = stripper.getText(document);

							LeitorNotasGrupoSocopa leitorSocopa = new LeitorNotasGrupoSocopa();
							leitorSocopa.setVetorLinhas(text);

							StringBuilder saida = new StringBuilder();
							saida.append("Arquivo").append("=").append(file.getName()).append(";");
							saida.append(leitorSocopa.extrairIdentificacao());
							saida.append(leitorSocopa.extrairOperacoesFinanceiras());
							// saida.append(leitorXP.extrairResumoNegocio());
							// saida.append(leitorXP.extrairResumoFinanceiro());
							// saida.append(leitorXP.extrairCustosOperacionais());
							// System.out.println(saida.toString());

							notas.add(new NotaCorretagem(saida.toString(), new Corretora("SOCOPA SC PAULISTA S.A.")));
						}
					}

					document.close();

					StringBuilder sbExport = new StringBuilder();
					for (NotaCorretagem notaCorretagem : notas) {
						StringBuilder sbExportTemp = new StringBuilder();

						for (OperacaoFinanceira operacaoFinanceira : notaCorretagem.getOperacaoes()) {

							sbExportTemp.append(operacaoFinanceira.exportStatusInvest()).append("\r\n");

//							 if (!operacaoFinanceira.exportAGF().equals("")) {
//								 sbExportTemp.append(operacaoFinanceira.exportAGF()).append("\r\n");
//							 }

							// System.out.print(new
							// StringBuilder(operacaoFinanceira.getNomeAtivo()).append("\r\n"));
						}
						sbExport.append(sbExportTemp);
						System.out.print(sbExportTemp.toString());
					}

					FileWriter fr = new FileWriter(new File(
							"D:\\TEMP\\notasGrupoSocopa\\output\\".concat(file.getName()).replaceAll("pdf", "csv")));
					fr.write(sbExport.toString());
					fr.flush();
					fr.close();

					sbExportCSV.append(sbExport);
				}

				FileWriter fr = new FileWriter(new File("D:\\TEMP\\notasGrupoSocopa\\output\\saida.csv"));
				fr.write(sbExportCSV.toString());
				fr.flush();
				fr.close();
			}

		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}
}
