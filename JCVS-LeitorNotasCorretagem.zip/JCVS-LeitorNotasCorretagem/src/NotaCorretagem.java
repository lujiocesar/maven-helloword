import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang3.StringUtils;

public class NotaCorretagem {

	private String nomeArquivo;
	private String nrNotaCorretagem;
	private String numFolha;
	private String dataPregao;
	
	private Corretora corretora;
	private List<OperacaoFinanceira> operacaoes;
	private ResumoNegocios resumoNegocios;
	private ResumoFinanceiro resumoFinanceiros;
	private CustosOperacionais custosOperacionais;
	
//	public NotaCorretagem(String notaCorretagem, Corretora corretora) {
//		this.corretora = corretora;
//		montarNotaCorretagem(notaCorretagem);
//	}

	public NotaCorretagem(String notaCorretagem, Corretora corretora) {
		this.corretora = corretora;
		montarNotaCorretagem(notaCorretagem);
	}

	public String getNomeArquivo() {
		return nomeArquivo;
	}

	public void setNomeArquivo(String nomeArquivo) {
		this.nomeArquivo = nomeArquivo;
	}

	public String getNrNotaCorretagem() {
		return nrNotaCorretagem;
	}

	public void setNrNotaCorretagem(String nrNotaCorretagem) {
		this.nrNotaCorretagem = nrNotaCorretagem;
	}

	public String getNumFolha() {
		return numFolha;
	}

	public void setNumFolha(String numFolha) {
		this.numFolha = numFolha;
	}

	public String getDataPregao() {
		return dataPregao;
	}

	public void setDataPregao(String dataPregao) {
		this.dataPregao = dataPregao;
	}

	public Corretora getCorretora() {
		return corretora;
	}

	public void setCorretora(Corretora corretora) {
		this.corretora = corretora;
	}

	public List<OperacaoFinanceira> getOperacaoes() {
		return operacaoes;
	}

	public void setOperacaoes(List<OperacaoFinanceira> operacaoes) {
		this.operacaoes = operacaoes;
	}

	public ResumoNegocios getResumoNegocios() {
		return resumoNegocios;
	}

	public void setResumoNegocios(ResumoNegocios resumoNegocios) {
		this.resumoNegocios = resumoNegocios;
	}

	public ResumoFinanceiro getResumoFinanceiros() {
		return resumoFinanceiros;
	}

	public void setResumoFinanceiros(ResumoFinanceiro resumoFinanceiros) {
		this.resumoFinanceiros = resumoFinanceiros;
	}

	public CustosOperacionais getCustosOperacionais() {
		return custosOperacionais;
	}

	public void setCustosOperacionais(CustosOperacionais custosOperacionais) {
		this.custosOperacionais = custosOperacionais;
	}

	private void montarNotaCorretagem(String notaCorretam) {
		String[] dados = null;

		if( notaCorretam != null ){

			dados = notaCorretam.split("@");

			String tempDados[] = dados[0].split(";"); //dados principal da nota

			this.nomeArquivo = tempDados[0].split("=")[1];

			this.nrNotaCorretagem = StringUtils.leftPad(tempDados[1].split("=")[1], 10, "0") ;
			this.numFolha = tempDados[2].split("=")[1];
			this.dataPregao = tempDados[3].split("=")[1];

			montarOperacaoesFinanceiras(dados[1]);

		}
	}
	
	private void montarOperacaoesFinanceiras( String operacoesFinanceiras ){
		this.operacaoes = new ArrayList<OperacaoFinanceira>();
		
		String[] dados = null;
		
		if( operacoesFinanceiras != null ){
			
			dados = operacoesFinanceiras.split("!");
			
			for (int i = 0; i < dados.length; i++) {
				this.operacaoes.add(new OperacaoFinanceira(dados[i], this));
			}
		}
		
	}
	
	public String toString() {
		
		StringBuilder sb = new StringBuilder();
		sb.append("nomeArquivo=").append(this.nomeArquivo).append(";");
		sb.append("nrNotaCorretagem=").append(this.nrNotaCorretagem).append(";");
		sb.append("numFolha=").append(this.numFolha).append(";");
		sb.append("dataPregao=").append(this.dataPregao).append(";");

		return sb.toString();
	}
	
	public String exportCSV(){
		StringBuilder sb = new StringBuilder();
		sb.append(this.corretora.getNome()).append(";");
		sb.append(this.nrNotaCorretagem).append(";");
		sb.append(this.dataPregao).append(";");
		
		return sb.toString();
	}
	
}
