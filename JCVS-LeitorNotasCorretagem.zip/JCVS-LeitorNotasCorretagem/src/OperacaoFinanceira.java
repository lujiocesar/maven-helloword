public class OperacaoFinanceira {

	private NotaCorretagem notaCorretagem;
	private String negociacao;
	private String tpOperacao;
	private String tpMercado;
	private String prazo;
	private String nomeAtivo;
	private String observacao;
	private String quantidade;
	private String precoAjuste;
	private String valorOperacao;
	private String tpOperacaoFinanceira;
	private String categoria;
	private String ticker;

	public OperacaoFinanceira(String operacaoFinanceira) {
		montarOperacaoFinanceira(operacaoFinanceira);
	}
	
	public OperacaoFinanceira(String operacaoFinanceira, NotaCorretagem notaCorretagem) {
		this.notaCorretagem = notaCorretagem;
		montarOperacaoFinanceira(operacaoFinanceira);
	}

	public NotaCorretagem getNotaCorretagem() {
		return notaCorretagem;
	}

	public void setNotaCorretagem(NotaCorretagem notaCorretagem) {
		this.notaCorretagem = notaCorretagem;
	}

	public String getNegociacao() {
		return negociacao;
	}

	public void setNegociacao(String negociacao) {
		this.negociacao = negociacao;
	}

	public String getTpOperacao() {
		return tpOperacao;
	}

	public void setTpOperacao(String tpOperacao) {
		this.tpOperacao = tpOperacao;
	}

	public String getTpMercado() {
		return tpMercado;
	}

	public void setTpMercado(String tpMercado) {
		this.tpMercado = tpMercado;
	}

	public String getPrazo() {
		return prazo;
	}

	public void setPrazo(String prazo) {
		this.prazo = prazo;
	}

	public String getNomeAtivo() {
		return nomeAtivo;
	}

	public void setNomeAtivo(String nomeAtivo) {
		this.nomeAtivo = nomeAtivo;
	}

	public String getObservacao() {
		return observacao;
	}

	public void setObservacao(String observacao) {
		this.observacao = observacao;
	}

	public String getQuantidade() {
		return quantidade;
	}

	public void setQuantidade(String quantidade) {
		this.quantidade = quantidade;
	}

	public String getPrecoAjuste() {
		return precoAjuste;
	}

	public void setPrecoAjuste(String precoAjuste) {
		this.precoAjuste = precoAjuste;
	}

	public String getValorOperacao() {
		return valorOperacao;
	}

	public void setValorOperacao(String valorOperacao) {
		this.valorOperacao = valorOperacao;
	}

	public String getTpOperacaoFinanceira() {
		return tpOperacaoFinanceira;
	}

	public void setTpOperacaoFinanceira(String tpOperacaoFinanceira) {
		this.tpOperacaoFinanceira = tpOperacaoFinanceira;
	}
	
	public String getCategoria() {
		return categoria;
	}

	public void setCategoria(String categoria) {
		this.categoria = categoria;
	}
	
	public String getTicker() {
		return ticker;
	}

	public void setTicker(String ticker) {
		this.ticker = ticker;
	}

	private void montarOperacaoFinanceira(String operacaoFinanceira) {
		String[] dados = null;

		if (operacaoFinanceira != null) {

			while (operacaoFinanceira.contains("  ")) {
				operacaoFinanceira = operacaoFinanceira.replaceAll("  ", " ");
			}
			
			operacaoFinanceira = operacaoFinanceira.replaceAll("BM&FBOVESPA S/A.", "BM&FBOVESPA");

			// System.out.println(operacaoFinanceira);

			dados = operacaoFinanceira.split(" ");
			// System.out.println(dados);

			int limiteInicial = 0;
			int limiteFinal = dados.length - 1;

			this.negociacao = dados[limiteInicial];
			this.tpOperacao = dados[++limiteInicial];
			this.tpMercado = dados[++limiteInicial];

			StringBuilder sbNomeAtivo = new StringBuilder();

			for (int i = (limiteInicial + 1); i < (limiteFinal - 3); i++) {
				sbNomeAtivo.append(dados[i]).append(" ");
			}
			this.nomeAtivo = TickerUtil.getTicker(sbNomeAtivo.toString().replaceAll("#", ""));
			
			if( this.nomeAtivo.contains("FII") || (this.nomeAtivo.contains("11") && !this.nomeAtivo.contains("BOVA"))){
				this.categoria = "FII";
			}else if( this.nomeAtivo.contains("DRN")){
				this.categoria = "BDR";
			}else if( this.nomeAtivo.contains("SHARE") || this.nomeAtivo.contains("BOVA")){
				this.categoria = "ETF";
			}else{
				this.categoria = "A��es";
			}
			
			this.ticker = TickerUtil.getTicker(this.nomeAtivo);

			this.quantidade = dados[limiteFinal - 3];
			this.precoAjuste = dados[limiteFinal - 2];
			this.valorOperacao = dados[limiteFinal - 1];
			this.tpOperacaoFinanceira = dados[limiteFinal];
			//
		}
	}

	public String exportCSV() {

		StringBuilder sb = new StringBuilder();
		sb.append(this.nomeAtivo).append(";");
		sb.append(this.tpOperacao).append(";");
		sb.append(this.tpMercado).append(";");
		sb.append(this.quantidade).append(";");
		sb.append(this.precoAjuste).append(";");
		sb.append(this.categoria).append(";");
		sb.append(this.ticker).append(";");

		return sb.toString();
	}
	
	public String exportStatusInvest() {

		StringBuilder sb = new StringBuilder();
		sb.append(this.notaCorretagem.getDataPregao()).append(";");
		sb.append(this.categoria).append(";");
		sb.append(this.ticker).append(";");
		sb.append(this.tpOperacao).append(";");
		sb.append(this.quantidade).append(";");
		sb.append(this.precoAjuste).append(";");
		sb.append(this.notaCorretagem.getCorretora().getNome()).append(";");
		sb.append(0).append(";"); // corretagem
		sb.append(0).append(";"); // taxas
		sb.append(0).append(";"); // impostos
		sb.append(0).append(";"); // IRRF
		return sb.toString();
	}
	
	public String exportAGF() {

		StringBuilder sb = new StringBuilder();
		sb.append(this.notaCorretagem.getDataPregao()).append(";");
		sb.append(this.ticker.toLowerCase()).append(";");
		sb.append(this.tpOperacao).append(";");
		sb.append(this.quantidade).append(";");
		sb.append(this.precoAjuste).append(";");
		
		if( this.ticker.equals("CLSA3") || !this.categoria.equals("A��es")){
			return "";
		}
		return sb.toString();
	}
}
