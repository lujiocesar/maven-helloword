
public class ResumoFinanceiro {

	private Double valorLiquidoOperacoes;
	private Double taxaLiquidacao;
	private Double taxaRegistro;
	private Double totalCBLC;
	private Double taxaTermoOpcoes;
	private Double taxaANA;
	private Double emolumentos;
	private Double totalBovespa;

	public Double getValorLiquidoOperacoes() {
		return valorLiquidoOperacoes;
	}

	public void setValorLiquidoOperacoes(Double valorLiquidoOperacoes) {
		this.valorLiquidoOperacoes = valorLiquidoOperacoes;
	}

	public Double getTaxaLiquidacao() {
		return taxaLiquidacao;
	}

	public void setTaxaLiquidacao(Double taxaLiquidacao) {
		this.taxaLiquidacao = taxaLiquidacao;
	}

	public Double getTaxaRegistro() {
		return taxaRegistro;
	}

	public void setTaxaRegistro(Double taxaRegistro) {
		this.taxaRegistro = taxaRegistro;
	}

	public Double getTotalCBLC() {
		return totalCBLC;
	}

	public void setTotalCBLC(Double totalCBLC) {
		this.totalCBLC = totalCBLC;
	}

	public Double getTaxaTermoOpcoes() {
		return taxaTermoOpcoes;
	}

	public void setTaxaTermoOpcoes(Double taxaTermoOpcoes) {
		this.taxaTermoOpcoes = taxaTermoOpcoes;
	}

	public Double getTaxaANA() {
		return taxaANA;
	}

	public void setTaxaANA(Double taxaANA) {
		this.taxaANA = taxaANA;
	}

	public Double getEmolumentos() {
		return emolumentos;
	}

	public void setEmolumentos(Double emolumentos) {
		this.emolumentos = emolumentos;
	}

	public Double getTotalBovespa() {
		return totalBovespa;
	}

	public void setTotalBovespa(Double totalBovespa) {
		this.totalBovespa = totalBovespa;
	}

}
