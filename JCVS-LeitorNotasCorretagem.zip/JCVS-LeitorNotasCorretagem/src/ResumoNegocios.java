
public class ResumoNegocios {

	private Double debentures;
	private Double vendasAVista;
	private Double comprasAVista;
	private Double opcoesCompras;
	private Double opcoesVendas;
	private Double operacoesTermo;
	private Double valorOperTituloPublico;
	private Double valorOperacoes;

	public Double getDebentures() {
		return debentures;
	}

	public void setDebentures(Double debentures) {
		this.debentures = debentures;
	}

	public Double getVendasAVista() {
		return vendasAVista;
	}

	public void setVendasAVista(Double vendasAVista) {
		this.vendasAVista = vendasAVista;
	}

	public Double getComprasAVista() {
		return comprasAVista;
	}

	public void setComprasAVista(Double comprasAVista) {
		this.comprasAVista = comprasAVista;
	}

	public Double getOpcoesCompras() {
		return opcoesCompras;
	}

	public void setOpcoesCompras(Double opcoesCompras) {
		this.opcoesCompras = opcoesCompras;
	}

	public Double getOpcoesVendas() {
		return opcoesVendas;
	}

	public void setOpcoesVendas(Double opcoesVendas) {
		this.opcoesVendas = opcoesVendas;
	}

	public Double getOperacoesTermo() {
		return operacoesTermo;
	}

	public void setOperacoesTermo(Double operacoesTermo) {
		this.operacoesTermo = operacoesTermo;
	}

	public Double getValorOperTituloPublico() {
		return valorOperTituloPublico;
	}

	public void setValorOperTituloPublico(Double valorOperTituloPublico) {
		this.valorOperTituloPublico = valorOperTituloPublico;
	}

	public Double getValorOperacoes() {
		return valorOperacoes;
	}

	public void setValorOperacoes(Double valorOperacoes) {
		this.valorOperacoes = valorOperacoes;
	}

}
